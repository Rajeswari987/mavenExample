package com.xml.demo;

public class Manager implements Employee {

	@Override
	public void doWork() {
		// TODO Auto-generated method stub
System.out.println("Manage the Branch Office....");
	}

}
