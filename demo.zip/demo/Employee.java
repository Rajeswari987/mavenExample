package com.xml.demo;

public interface Employee {
void doWork();


}
