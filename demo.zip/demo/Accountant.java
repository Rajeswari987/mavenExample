package com.xml.demo;

public class Accountant implements Employee {

	@Override
	public void doWork() {
		// TODO Auto-generated method stub
System.out.println("Audit the accounts......");
	}

	}


